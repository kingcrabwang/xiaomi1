# MiNotes
[中文]

1. MiCode便签是小米便签的社区开源版，由MIUI团队(www.miui.com) 发起并贡献第一批代码，遵循NOTICE文件所描述的开源协议，
   今后为MiCode社区(www.micode.net) 拥有，并由社区发布和维护。

2. Bug反馈和跟踪，请访问Github,
   https://github.com/MiCode/Notes/issues?sort=created&direction=desc&state=open

3. 功能建议和综合讨论，请访问MiCode,
   http://micode.net/forum.php?mod=forumdisplay&fid=38


[English]

1. MiCode Notes is open source edition of XM notepad, it's first initiated and sponsored by MIUI team (www.miui.com).
   It's opened under license described by NOTICE file. It's owned by the MiCode community (www.micode.net). In future,
   the MiCode community will release and maintain this project.

2. Regarding issue tracking, please visit Github,
   https://github.com/MiCode/Notes/issues?sort=created&direction=desc&state=open

3. Regarding feature request and general discussion, please visit Micode forum,
   http://micode.net/forum.php?mod=forumdisplay&fid=38
